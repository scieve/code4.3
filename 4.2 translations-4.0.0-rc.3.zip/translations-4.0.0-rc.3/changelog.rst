##########
Change Log
##########

Version 4.0-dev
==============================

Release Date: Unreleased

-   New Translations
   
-   Updated Translations

Version 4.0.0-rc.3
==============================

Release Date: Oct 19, 2019

-   New Translations
   
-   Updated Translations

   - ar (Arabic)
   - de (German)
   - es (Spanish)
   - fa (Farsi)
   - fr (French)
   - id (Indonesian)
   - it (Italian)
   - no Norwegian
   - pl (Polish)
   - pt (Portugese)
   - pt-BR (Brazilian)
   - ru (Russian)
   - sk (Slovak)
   - tr (Turkish)
   - zh-CN (Simplified Chinese)

Version 4.0.0-rc.2
==============================

Release Date: Sept 26, 2019

-   New Translations
   
-   Updated Translations

   - no (Norwegian)
   - ru (Russian)
   - sk (Slovak)

Version 4.0-beta4
==============================

Release Date: Aug 9, 2019

-   New Translations
   
   - no (Norwegian)
   - sk (Slovak)
   
-   Updated Translations

   - ru (Russian)

      
Version 4.0-beta.3
==============================

Release Date: May 6, 2019

-   New Translations

      - ru (Russian)
   
-   Updated Translations

      - pt-BR (Brazilian)
   
Version 4.0-beta.2
==============================

Release Date: Apr 4, 2019

-   Updated Translations

      - ar (Arabic)
   
Version 4.0-beta.1
==============================

Release Date: Mar 1, 2019

-   New Translations

    - fa (Farsi)
    - zh-CN (Simplified Chinese)
    
-   Updated Translations

    - de (German)
    - es (Spanish)
    - pl (Polish)
    
Version 4.0-alpha.5
==================================

Release Date: Jan 30, 2019

-   New Translations

-   Updated Translations

    - it (Italian)
    - es (Spanish)
    
Version 4.0-0-alpha.4
====================================

Release Date: Dec 15, 2018

-   New Translations

    - fr (French)
    - it (Italian)
    
Version 4.0.0-alpha.3
====================================

Release Date: Nov 30, 2018

Initial "official" release, with settings consistent with CodeIgniter 4.0.0

-   New Translations

    - ar (Arabic)
    - es (Spanish)
    - id (Indonesian)
    - pl (Polish)
    - pt (Portugese)
    - pt-BR (Brazilian)
    - tr (Turkish)
