<?php
// 12 days of Christmas
return [
   'for' => 'four calling birds',
   'fiv' => 'five golden rings',
   'six' => 'six geese a laying',
   'sev' => 'seven swans a swimming',
];
